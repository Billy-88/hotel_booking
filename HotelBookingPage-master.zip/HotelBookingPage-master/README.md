# HotelBookingPage

A web page for booking hotels. The data are loaded from a JSON file.

Individual project developed over the Coding BootCamp, C# Stream – PeopleCert Education.

Disclaimer: Due to the CORS policy of the browsers, in order to load the data you have to run the app through a server (e.g. IIS)
